Riffic
https://www.dafont.com/riffic.font